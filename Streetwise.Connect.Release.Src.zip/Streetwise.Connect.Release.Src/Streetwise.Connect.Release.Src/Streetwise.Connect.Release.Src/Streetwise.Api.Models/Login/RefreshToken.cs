﻿namespace Streetwise.Api.Models
{
    public class RefreshToken : BaseModel
    {

    }
}
