﻿using System;

namespace Streetwise.Api.Models
{
    public class NopCommerceProductPromotionExport
    {
        public string LocationCode { get; set; }
        public string ProductCode { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string PromotionId { get; set; }
        public string PromotionType { get; set; }
        public string PromotionGroupId { get; set; }
        public int QtyQualify { get; set; }
        public decimal PromotionPrice { get; set; }
        public string Description { get; set; }
    }
}
