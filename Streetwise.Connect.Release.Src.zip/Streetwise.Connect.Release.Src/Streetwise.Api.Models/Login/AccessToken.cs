﻿using System;

namespace Streetwise.Api.Models
{
    public class AccessToken
    {
        public DateTime IssueTime { get; set; }
        public DateTime ExpireTime { get; set; }
        public string ClientId { get; set; }
        public string UserGuid { get; set; }
        public string ClientIp { get; set; }
    }
}
