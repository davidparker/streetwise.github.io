﻿namespace Streetwise.Api.Models
{
    public static class OrderUpdateStatus
    {
        public const string Updated = "U";
        public const string New = "N";
        public const string Deleted = "D";
    }
}
