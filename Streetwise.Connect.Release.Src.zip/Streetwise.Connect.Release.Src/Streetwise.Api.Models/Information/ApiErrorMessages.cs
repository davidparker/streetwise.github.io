﻿using System.Collections.Generic;
using System.Linq;

namespace Streetwise.Api.Models
{
    public static class ApiErrorMessages
    {
        public const string ExpiredLogin = "Token expired, please login again";
        public const string AccessDenied = "Access Denied";
        public const string MissingClientId = "ClientId cannot be null";
        public const string MissingClientSecret = "Client Secret cannot be null";
        public const string MissingAccessToken = "You must provide an access token";
        public const string TransportError = "Transport error with status code";
        public const string NoValidContent = "You must provide content in the data field";
        public const string ValidationError = "Please check validation errors for details";
        public const string GeneralException = "An exception happened, we have logged the details";

        /// <summary>
        /// Use this to compare error message, against existing messages
        /// </summary>
        /// <returns></returns>
        public static List<string> GetAll()
        {
            return (from d in typeof(ApiErrorMessages).GetFields() select d.GetRawConstantValue().ToString()).ToList();
        }
    }
}
