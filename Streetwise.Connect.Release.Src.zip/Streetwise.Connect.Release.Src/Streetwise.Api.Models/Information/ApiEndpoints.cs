﻿namespace Streetwise.Api.Models
{
    public class ApiEndpoints
    {
        public const string PostOnlineOrderDetail = "api/OnlineOrderDetail/Create";


        public const string CreateOrder = "api/Order/Create";
        public const string UpdateOrder = "api/Order/Update";

        public const string UpdateOrderItem = "api/OrderItem/Update";
        public const string CreateOrderItem = "api/OrderItem/Create";

        public const string AddOrderAddress = "api/OrderAddress/Create";
        public const string UpdateOrderAddress = "api/OrderAddress/Update";
    }
}
