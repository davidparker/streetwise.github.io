﻿namespace Streetwise.Api.Models
{
    public class BaseIntIdModel
    {
        public int Id { get; set; }
    }
}
