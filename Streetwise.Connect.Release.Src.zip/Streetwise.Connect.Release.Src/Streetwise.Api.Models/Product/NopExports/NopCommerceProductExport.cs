﻿using System;

namespace Streetwise.Api.Models
{
    public class NopCommerceProductExport
    {
        public string DepartmentId { get; set; }
        public string DepartmentGroupId { get; set; }
        public string ProductCode { get; set; }
        public string RetailLineId { get; set; }
        public string NslCode { get; set; }
        public string EanCode { get; set; }
        public string Description { get; set; }
        public string ProductSize { get; set; }
        public int MaxSaleQty { get; set; }
        public int MinAge { get; set; }
        public DateTime LastChanged { get; set; }
    }
}
