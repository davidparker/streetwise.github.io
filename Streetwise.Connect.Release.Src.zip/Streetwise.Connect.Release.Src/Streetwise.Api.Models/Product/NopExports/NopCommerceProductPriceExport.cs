﻿namespace Streetwise.Api.Models
{
    public class NopCommerceProductPriceExport
    {
        public string LocationCode { get; set; }
        public string ProductCode { get; set; }
        public decimal SellPrice { get; set; }
        public decimal TaxRate { get; set; }
    }
}
