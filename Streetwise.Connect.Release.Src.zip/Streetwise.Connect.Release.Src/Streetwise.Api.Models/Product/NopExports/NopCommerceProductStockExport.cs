﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Streetwise.Api.Models
{
    public class NopCommerceProductStockExport
    {
        public string LocationCode { get; set; }
        public string ProductCode { get; set; }

        ///0=Out of Stock, 1=Low Stock, 2=Stock Available        
        public int StockStatus { get; set; }

    }
}
