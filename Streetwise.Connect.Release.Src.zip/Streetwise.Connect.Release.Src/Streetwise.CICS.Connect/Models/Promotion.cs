namespace Streetwise.CICS.Connect.Models
{
    public class Promotion
    {
        public string Id { get; set; }

        public string PromotionType { get; set; }
               
        public string LocationCode { get; set; }

        public string ProductCode { get; set; }

        public string StartDate { get; set; }

        public string EndDate { get; set; }

        public int? PromotionGroup { get; set; }

        public decimal PromotionPrice { get; set; }
        
        public string PromotionDescription { get; set; }
    }
}
