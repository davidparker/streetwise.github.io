namespace Streetwise.CICS.Connect.Models
{
    public class ApiResponse
    {       
        public bool? Success { get; set; }
       
        public int? Code { get; set; }
        
        public string Message { get; set; }
    }
}
