using System.Collections.Generic;

namespace Streetwise.CICS.Connect.Models
{
    public class Product
    {
        public string ProductCode { get; set; }

        public string DepartmentId { get; set; }

        public string GroupId { get; set; }

        public string RetailLineId { get; set; }

        public string NslCode { get; set; }

        public string EanCode { get; set; }

        public string Description { get; set; }

        public string Size { get; set; }

        public int MaxPerOrder { get; set; }

        public int MinAge { get; set; }

        public List<Image> Images { get; set; }

        public string LastUpdatedDate { get; set; }

        public List<KeyValuePair> Attributes { get; set; }

        public bool IsDeleted { get; set; }
    }

    public class KeyValuePair
    {
        public string Key { get; set; }
        public string Value { get; set; }
    }
}
