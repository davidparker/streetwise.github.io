namespace Streetwise.CICS.Connect.Models
{
    public class Image
    {        
        public string FileName { get; set; }

        public string LastUpdatedDate { get; set; }

        public string Base64data { get; set; }

        public int? FileSizeKb { get; set; }

        public bool? IsPrimaryImage { get; set; }
    }
}
