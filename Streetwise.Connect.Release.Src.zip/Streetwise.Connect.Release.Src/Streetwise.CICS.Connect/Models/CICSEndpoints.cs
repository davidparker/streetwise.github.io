﻿namespace Streetwise.CICS.Connect.Models
{
    public static class CICSEndpoints
    {
        public const string Products = "/ProductApi/Product";
        public const string Categories = "/categorisationApi/categorisation";
        public const string Prices = "/PriceApi/Price";
        public const string Promotions = "/PromotionApi/Promotion";
        public const string Stock = "/StockApi/Stock";
        public const string Delivery = "/DeliveryApi/Delivery";
    }
}
