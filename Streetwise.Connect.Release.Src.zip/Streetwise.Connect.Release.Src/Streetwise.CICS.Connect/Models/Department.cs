using System.Collections.Generic;

namespace Streetwise.CICS.Connect.Models
{
    public class Department
    {     
        public string Id { get; set; }

        public string Name { get; set; }

        public List<Group> Groups { get; set; }
    }
}
