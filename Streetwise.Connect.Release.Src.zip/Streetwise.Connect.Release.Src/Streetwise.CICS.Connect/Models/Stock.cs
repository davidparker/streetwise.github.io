namespace Streetwise.CICS.Connect.Models
{
    public class Stock
    {        
        public string LocationCode { get; set; }
        public string ProductCode { get; set; }
        public int StockStatus { get; set; }
    }
}
