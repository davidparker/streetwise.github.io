namespace Streetwise.CICS.Connect.Models
{
    public class Price
    {        
        public string LocationCode { get; set; }

        public string ProductCode { get; set; }

        public decimal? SellPrice { get; set; }

        public int? TaxCode { get; set; }

        public string UnitPriceDescription { get; set; }

    }
}
