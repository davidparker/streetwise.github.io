namespace Streetwise.CICS.Connect.Models
{
    public class DeliveryItem
    {        
        public string PickDate { get; set; }

        public string ProductCode { get; set; }

        public int? QuantityRequired { get; set; }

        public int? QuantityPicked { get; set; }

        public decimal PickingPrice { get; set; }

        public string PromotionId { get; set; }
    }
}
