using System.Collections.Generic;

namespace Streetwise.CICS.Connect.Models
{
   
    public class Delivery
    {        
        public string LocationCode { get; set; }

        public string OrderId { get; set; }

        public string MemberNumber { get; set; }

        public string OrderDate { get; set; }

        public List<DeliveryItem> Items { get; set; }
    }
}
