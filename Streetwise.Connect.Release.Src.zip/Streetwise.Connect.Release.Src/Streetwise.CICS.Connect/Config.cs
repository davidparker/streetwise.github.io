﻿namespace Streetwise.CICS.Connect
{
    public static class Config
    {
        public const string DateTimeFormat = "O";
    }
}
