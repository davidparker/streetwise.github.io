﻿using Newtonsoft.Json;
using Streetwise.CICS.Connect.Models;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Streetwise.CICS.Connect.Services
{
    public class SendDataService
    {
        private string _apiKey;
        private string _url;
        protected readonly HttpClient _client = new HttpClient();

        public SendDataService(string apiKey, string url)
        {
            _apiKey = apiKey;
            _url = url;
            SetHeaders();
        }

        public async Task<ApiResponse> PostData(object obj, string endpoint)
        {
            var request = await _client.PostAsync($"{_url}{endpoint}", JsonContent(obj));

            if (request.IsSuccessStatusCode)
            {
                var response = JsonConvert.DeserializeObject<ApiResponse>(await request.Content.ReadAsStringAsync());
                return response;
            }

            return new ApiResponse { 
                Code = 500, 
                Message = $"Transport error with status code {request.StatusCode} and message {request.ReasonPhrase}", 
                Success = false 
            };
        }

        private void SetHeaders()
        {
            _client.DefaultRequestHeaders.Accept.Clear();
            _client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            _client.DefaultRequestHeaders.Add("User-Agent", "Streetwise.CICS.Connect");
            _client.DefaultRequestHeaders.Add("api_key", _apiKey);
        }
        private StringContent JsonContent(object obj)
        {
            return new StringContent(JsonConvert.SerializeObject(obj), Encoding.UTF8, "application/json");
        }
    }
}
