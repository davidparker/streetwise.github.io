﻿using Autofac;
using Nop.Core.Configuration;
using Nop.Core.Infrastructure;
using Nop.Core.Infrastructure.DependencyManagement;
using Nop.Services.Common;

namespace Nop.Plugin.Misc.TestStreetwiseApi.Infrastructure
{
    public class DependencyRegistrar : IDependencyRegistrar
    {
        public void Register(ContainerBuilder builder, ITypeFinder typeFinder, NopConfig config)
        {
            builder.RegisterType<TestStreetwiseApiProvider>().As<IMiscPlugin>().InstancePerLifetimeScope();
        }

        public int Order => 1;
    }
}
