﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Nop.Web.Framework.Mvc.Routing;

namespace Nop.Plugin.Misc.TestStreetwiseApi.Infrastructure
{
    public partial class RouteProvider : IRouteProvider
    {
        /// <summary>
        /// Register routes
        /// </summary>
        /// <param name="endpointRouteBuilder">Route builder</param>
        public void RegisterRoutes(IEndpointRouteBuilder endpointRouteBuilder)
        {
            //GetAll API
            endpointRouteBuilder.MapControllerRoute("Plugin.Streetwise.testapi.GetAll", "Plugins/TestStreetwiseApi/SendOrder/Process/{Id}",
                 new { controller = "SendOrder", action = "Process" });

            
        }

        /// <summary>
        /// Gets a priority of route provider
        /// </summary>
        public int Priority => -1;
    }
}