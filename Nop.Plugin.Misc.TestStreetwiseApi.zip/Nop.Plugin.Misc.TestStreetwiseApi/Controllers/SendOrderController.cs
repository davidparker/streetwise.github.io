﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Nop.Services.Common;
using Nop.Services.Orders;
using Nop.Web.Framework.Controllers;
using NUglify.Helpers;
using Streetwise.Api.Models;
using System.Collections.Generic;
using System.Linq;

namespace Nop.Plugin.Misc.TestStreetwiseApi.Controllers
{
    public class SendOrderController : BasePluginController
    {
        private readonly IOrderService _orderService;
        private readonly IAddressService _addressService;

        public SendOrderController(IOrderService orderService, IAddressService addressService)
        {
            _orderService = orderService;
            _addressService = addressService;
        }

        public IActionResult Process(int id)
        {
            var order = _orderService.GetOrderById(id);

            if(order != null)
            {

                if(order.ShippingAddressId == null)
                    return new JsonResult(new ApiResponse { Success = false, ErrorMessage = "NO delivery address present" });

                var orderItems = _orderService.GetOrderItems(id);

                if(orderItems.Count > 0)
                {
                    // we have an order and order items.  
                    // we now need the delivery address and any notes
                    var orderNotes = "";
                    var notes = _orderService.GetOrderNotesByOrderId(id);

                    if (notes.Count > 0)
                        orderNotes = string.Join(", ", notes.Select(x => x.Note).ToList());

                    var address = _addressService.GetAddressById((int)order.ShippingAddressId);

                    // now to compile the order information
                    var orderDetails = new OnlineOrderDetail
                    {
                        // we could set up automapper here, but will show raw in order to
                        // fully test
                        DeliveryAddress = new OnlineOrderDeliveryAddressDto
                        {
                            Address1 = address.Address1,
                            Address2 = address.Address2,
                            City = address.City, 
                            Company = address.Company, 
                            County = address.County, 
                            Email = address.Email, 
                            FirstName = address.FirstName, 
                            LastName = address.LastName, 
                            PhoneNumber = address.PhoneNumber, 
                            ZipPostalCode = address.ZipPostalCode
                        }, 
                        OrderDetails = new OnlineOrderDto 
                        {
                            OrderDate = order.CreatedOnUtc, 
                            CustomerGuid = order.CustomerId.ToString(), // or lookup customer guid
                            DeliveryCharge = order.OrderShippingInclTax, 
                            IsStaffMember = false,
                            MemberCode = 123, 
                            Notes = orderNotes, 
                            OrderNo = order.OrderGuid.ToString(), 
                            TotalOrderValue = order.OrderTotal
                        }, 
                        OrderItems = new List<OnlineOrderItemsDto>()
                    };

                    orderItems.ForEach(x => orderDetails.OrderItems.Add(new OnlineOrderItemsDto 
                    { 
                        OrderNo = order.OrderGuid.ToString(), 
                        OrderRowId = x.Id.ToString(), 
                        ProductCode = "123456789", 
                        PromotionId = "free willy", 
                        PurchasePrice = x.PriceInclTax, 
                        StandardSellingPrice = x.OriginalProductCost, 
                        QtyRequired = x.Quantity 
                    }));

                    // order compiled.  Now to sign in and send order:
                    var APIservice = new Streetwise.Api.Connect.ApiAccessService();

                    var ApiUrl = "https://localhost:44319/";

                    var login = APIservice.GetLogin("sasas", "asasas", ApiUrl).GetAwaiter().GetResult();

                    if (login.IsSuccess)
                    {
                        var sendResponse = APIservice.SendData(new RequestModel { 
                            AccessToken = login.AccessToken, 
                            Data = JsonConvert.SerializeObject(orderDetails) 
                        }, ApiUrl, ApiEndpoints.PostOnlineOrderDetail).GetAwaiter().GetResult();

                        // deal with validation or other errors
                        if (sendResponse.Success)
                            return new JsonResult(sendResponse);

                        /// log errors,  mark as not sent etc   
                        /// do something else,  whatever.   but if you got here, something is up
                        /// you could do somethig like:
                        /// 

                        if(sendResponse.ErrorMessage != ApiErrorMessages.GeneralException)
                        {
                            // then problem is with the data, and not an exception on the api
                            
                        }

                        return new JsonResult(sendResponse);
                    }

                    return new JsonResult(new ApiResponse { Success = false, ErrorMessage = login.ErrorMessage });
                }
            }

            return new JsonResult(new ApiResponse { Success = false, ErrorMessage = "NO order can be found" });
        }
    }
}
