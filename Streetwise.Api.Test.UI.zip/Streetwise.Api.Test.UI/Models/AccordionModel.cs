﻿namespace Streetwise.Api.Test.UI.Models
{
    public class AccordionModel
    {
        public string HeaderId { get; set; }
        public string ContainerId { get; set; }
        public string TypeName { get; set; }
        public string Label { get; set; }
    }
}
