﻿var inactivityTime = function () {
    var time;
    window.onload = resetTimer;
    document.onmousemove = resetTimer;
    document.onkeypress = resetTimer;

    function logout() {
        clearTimeout(time);
        localStorage.removeItem('auth');
        location.href = '/';
    }

    function resetTimer() {
        clearTimeout(time);
        time = setTimeout(logout, 720000);
    }
};

var streetwiseApi = (function () {

    var tokenRefresh = null, spinner = '<span class="spinner-border spinner-border-sm text-success" role="status" aria-hidden="true"></span>';

    var urls = {
        api: 'https://streetwiseapi.azurewebsites.net/',
        auth: {
            login: 'api/ApiAuthenticate/Login',
            renew: 'api/ApiAuthenticate/RenewToken'
        },
        exporting: {
            categories: 'api/ExportCategory/GetAll',
            prices: 'api/ExportPrice/GetAll',
            products: 'api/ExportProduct/GetAll',
            promotions: 'api/ExportPromotion/GetForLocation',
            stock: 'api/ExportStock/GetAll',
            log: 'api/ExportLog/CreateLog',
            latestProducts: 'api/ExportProduct/GetProductChanges'
        },
        cics: {
            category: "categorisation",
            delivery : "delivery",
            price: "price",
            product: "product",
            promotion: "promotion",
            stock: "stock"
        }
    };

    var messageTypes = {
        error: 'errorMessage',
        info: 'infoMessage',
        good: 'goodMessage'
    };

    var elements = {
        misc: { counter: '#counter', actionBtn: '.actionBtn', spinner: '.spinner-border' },
        login: { btn: '#login', id: '#clientid', secret: '#clientsecret' },
        storeKeys: { auth: 'auth' },
        testPanel: {
            actionBtn: '.btnRunTest'
        },
        settings: {
            url: '#apiUrl',
            apikey: '#apikey',
            location: '#loc'
        }
    };

    function displayMessage(type, header, message) {
        var timeleft = 10;
        var heading = `<h4 class="alert-heading">${header} <span class="badge" id="counter">${timeleft}</span></h4 >`;
        var element = $(`#${type}`);

        $(element).removeClass('d-none').html(`${heading}<p>${message}</p>`);
                
        var showTimer = setInterval(function () {
            if (timeleft <= 0) {
                clearInterval(showTimer);
                $(element).addClass('d-none');
            } else {
                timeleft -= 1;
                $(elements.misc.counter).html(timeleft);
            }
            
        }, 1000);

        setTimeout(function () { $(element).addClass('d-none'); }, 15000);
    }

    function store (data, key){
        localStorage.setItem(key, JSON.stringify(data));
    }

    function getFromStore(key) {
        return JSON.parse(localStorage.getItem(key));
    }
        
    function serialize(data) {
        try {
            return JSON.stringify(data);
        } catch (e) {
            return data;
        }
    }   

    function post(url, data) {
        return new Promise(function (done) {
            $.ajax({
                type: "POST",
                url: `${urls.api}${url}`,                
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: serialize(data),
                success: function (response) {                    
                    done(response);
                },
                error: function (x, textStatus, errorThrown) {
                    if (x.responseText.indexOf('success') >= 0) {
                        done(JSON.parse(x.responseText));
                    } else {
                        displayMessage(messageTypes.error, 'Transport Error', `${textStatus} - ${errorThrown}`);
                        done({ success: false });
                    }
                    
                },
                complete: function () {
                    $(elements.misc.spinner).remove();
                }
            });
        });
    }

    function auth(url, data) {
        return new Promise(function (done) {
            $.ajax({
                type: "POST",
                url: `${urls.api}${url}`,
                beforeSend: function () {
                    $(elements.misc.actionBtn).prepend(spinner);
                },
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: serialize(data),
                success: function (response) {
                    done({ success: response.isSuccess, data: response });
                },
                error: function (x, textStatus, errorThrown) {
                    displayMessage(messageTypes.error, 'Transport Error', `${textStatus} - ${errorThrown}`);
                    done({ success: false, data: null });
                },
                complete: function () {
                    $(elements.misc.spinner).remove();
                }
            });
        });
    }

    function isNothing(item) {
        return (item === undefined || item === null || item.length <= 0);
    }

    function home() {
        try {
            clearInterval(tokenRefresh);
            location.href = '/';
        } catch (e) {
            location.href = '/';
        }        
    }

    function renewToken() {
        var existingAuth = getFromStore(elements.storeKeys.auth);

        if (isNothing(existingAuth)) home();
        if (isNothing(existingAuth.accessToken)) home();

        post(urls.auth.renew, { accessToken: existingAuth.accessToken }).then(function (r) {
            try {
                if (r.isSuccess) {

                    try {
                        clearInterval(tokenRefresh);
                    } catch (e) {
                        // no problem, doesent exist
                    }
                    store(r, elements.storeKeys.auth);
                    tokenRefresh = setInterval(renewToken, 300000); // refresh token every 5 mins
                } else {
                    home();
                }
            } catch (e) {
                home();
            }
        });
    }

    function getAccessToken() {
        var existingAuth = getFromStore(elements.storeKeys.auth);

        if (isNothing(existingAuth)) home();
        if (isNothing(existingAuth.accessToken)) home();

        return existingAuth.accessToken;
    }

    function updateFeedbackWindow(window, message)
    {
        $('#' + window).html(message);
    }
                
    function runTest(clicked) {        
        var callType = $(clicked).data('type');
        var resultWindow = $(clicked).data('result');
        var feedbackWindow = $(clicked).data('feedback');
        var loc = $(elements.settings.location).val();

        updateFeedbackWindow(feedbackWindow, 'Starting ....');
       
        var collectEndpoint = '';

        switch (callType) {

            case 'category':
                collectEndpoint = urls.exporting.categories;
                break;
            case 'prices':
                collectEndpoint = urls.exporting.prices;
                break;
            case 'products':
                collectEndpoint = urls.exporting.products;
                break;
            case 'productUpdate':
                collectEndpoint = urls.exporting.latestProducts;
                break;
            case 'promotion':
                if (isNothing(loc)) {
                    updateFeedbackWindow(feedbackWindow, 'ERROR: location is required for this endpoint....');
                    return false;
                }
                collectEndpoint = urls.exporting.promotions;
                break;
            case 'stock':
                collectEndpoint = urls.exporting.stock;
                break;            
        }
        
        updateFeedbackWindow(feedbackWindow, 'Processing ....'); 

        post(collectEndpoint, { accessToken: getAccessToken(), data: loc }).then(function (r) {
            if (r.success) {
                updateFeedbackWindow(feedbackWindow, 'Finished, checking results.');

                var objResult = JSON.parse(r.item);

                $('#' + resultWindow).html(JSON.stringify(objResult));

                if (!objResult.Success) {
                    updateFeedbackWindow(feedbackWindow, 'ERROR: Sending data');
                } else {
                    updateFeedbackWindow(feedbackWindow, 'Sending data completed');
                }                
            }
        });                
    }
   

    return {
        init: function () {
            $(elements.login.btn).off().on('click', function (e) {
                $(this).addClass('disabled');
                e.preventDefault();
                streetwiseApi.login();
            });
        },
        login: function () {
            var id = $(elements.login.id).val();
            var secret = $(elements.login.secret).val();

            auth(urls.auth.login, { ClientId: id, ClientSecret: secret }).then(function (d) {                
                if (d.success) {
                    store(d.data, elements.storeKeys.auth);
                    location.href = '/Process';
                } else {
                    if (d.data !== null) {
                        displayMessage(messageTypes.error, 'Failed Login', d.data.errorMessage);
                    }                    
                }
                $(elements.login.btn).removeClass('disabled');
            });
        },
        auth: function () {
            renewToken();
            $(elements.testPanel.actionBtn).off().on('click', function (e) {
                e.preventDefault();
                runTest(this);
            });
            // make sure we logout on inactivity
            inactivityTime();
        }
    };

})();
